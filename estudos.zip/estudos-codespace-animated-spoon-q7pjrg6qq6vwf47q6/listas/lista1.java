package listas;

public class lista1 {
    
public static void main(String[] args) {
    







    
    }
}
