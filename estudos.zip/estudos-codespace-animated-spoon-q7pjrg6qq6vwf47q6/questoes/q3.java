package questoes;


public class q3 {
    public static void main(String[] args) {

int [] a =  {1,2,3,4,5};
int [] b =  {2,4,6,7,8};
int [] c = new int[5];

for (int i = 0; i < 5; i++) {
    c[i] = a[i] + b[i];
 }
 for(int i=0; i<5; i++){
    System.out.println(c[i]);
 }


    }
}





