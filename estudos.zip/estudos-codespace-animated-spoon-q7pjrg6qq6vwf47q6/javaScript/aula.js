



/*const t1 = false
const t2 = false



let compraTV50 = t1 && t2;
console.log('vamos comprar a TV 50:',compraTV50);

let compraTV32 = t1 !== t2;
console.log('vamos comprar uma TV 32:',compraTV32);

let tomarSorvete = t1 || t2;
console.log('vamos comprar um sorvete:',tomarSorvete);

let ficarEmCasa = !tomarSorvete;
console.log("vamos ficar em casa:",ficarEmCasa);*/



/*function mFuncao1() {
    let muda = true;
    let x = document.getElementById("paragrafo");
    while (muda) {
        x.innerHTML = "Hello";

    }
    function mFuncao2() {

        let y = document.getElementById("paragrafo2");
        y.innerHTML = "Olá";

    }
}*/



var texto = window.confirm("escolha uma");
window.alert("você selecionou: " + texto);


carros = new Array();
carros[0] = "volvo";
carros[5] = "BMW";
carros[7] = "volkswagen";

